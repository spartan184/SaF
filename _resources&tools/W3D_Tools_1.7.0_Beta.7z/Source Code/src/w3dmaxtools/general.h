#pragma once

#ifndef W3D_MAX_TOOLS_INCLUDE_GENERAL_H
#define W3D_MAX_TOOLS_INCLUDE_GENERAL_H
#include "Defines.h"
#include "Standard.h"
#endif // W3D_MAX_TOOLS_INCLUDE_GENERAL_H