//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wdump.rc
//
#define IDI_MAIN                        104
#define IDR_MAINMENU                    108
#define IDR_ACCEL                       109
#define ID_OPEN                         40025
#define ID_EXIT                         40026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40033
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
