#ifndef W3DMAPPER_INCLUDE__GENERAL_H
#define W3DMAPPER_INCLUDE__GENERAL_H
#include "Defines.h"
#include "Standard.h"
#endif