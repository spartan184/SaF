#ifndef TT_INCLUDE__STANDARD_H
#define TT_INCLUDE__STANDARD_H

// put includes from STL and other standard or third-party libraries here

#include <array>
#include <assert.h>
#include <errno.h>
#include <float.h>
#include <intrin.h>
#include <math.h>
#include <memory>
#include <new>
#include <process.h>
#include <shlwapi.h>
#include <stdarg.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <tlhelp32.h>
#include <wchar.h>
#if (_MSVC_LANG >= 201703L)
#include <charconv>
#endif
//

// the order of these includes is essential
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <wininet.h>
#include <dbghelp.h>
#define DIRECTINPUT_VERSION 0x800
#include <dinput.h>
#include <imm.h>

#include "MemoryManager.h"
#include "Profiler.h"

#endif
