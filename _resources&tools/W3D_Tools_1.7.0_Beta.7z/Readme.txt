============================================================================
--------------------------------- Contents ---------------------------------
============================================================================
This pack contains:

- W3D Exporter for 3DS Max 2017 - New tools for Max 2017 to export W3D files from
- W3D Viewer -  A model viewer for W3D files
- W3D Dump - A tool to open W3D files and see the contents
- The source code to to the W3D Exporter, wdump.exe and memorymanager.dll


============================================================================
-------------------------------- Information -------------------------------
============================================================================
The new w3d tools require 3DS Max 2017 to work. (tools for other recent versions of Max such as 2019 may be possible but porting and testing would be required)

The new w3d tools are 100% compatible with files made in Max 8 with the old w3d tools. When you load an old file, WWSkin data is converted to Max skin data automatically. All the material settings and export flags will be read in and converted as well.
If you are using the DirectX Material feature to produce models for BFME2, you will need to make sure that your DirectX Materials point at the correct path where the .fx files are located.
You also need to go to Customize-Preferences, click on the Viewports tab, select "Choose Driver" and then choose "Legacy Direct3D". This is necessary to allow Max to be able to load the .fx shader files properly.

Features from the old plugins not currently supported:

Animation compression
NPatches (hardware that actually supports this feature has long since vanished and current versions of Renegade no longer support it)
Export with Std Mtls
Create Settings Floater
Full documentation can be found here: http://tacitus.w3dhub.com/display/WH/W3D+3DS+Max+Tools

============================================================================
------------------------------ How to Install ------------------------------
============================================================================
- Install the latest release of Max 2017 from https://knowledge.autodesk.com/support/3ds-max/downloads/caas/downloads/content/3ds-max-201702-security-fix.html (this was the last Max 2017 update released by Autodesk and is required for the BFME2 DirectX Material feature to work. It will install on any version of Max 2017 including student versions.)
- Download the files!
- Copy the the files in the "W3D Exporter - Max 2017" folder to your 3DS Max 2017 directory. Default: "C\Program Files\Autodesk\3ds Max 2017\Plugins"
- Run 3DS Max and the tools will load with it!
- For W3D viewer and W3D Dump, they can be run directly from the folder that they are already in, so they can be copied anywhere.

Note: If you have any issues with any missing files, you should install these Visual C++ Redistributable from Microsoft: https://aka.ms/vs/16/release/vc_redist.x86.exe and https://aka.ms/vs/16/release/vc_redist.x64.exe

There is a separate readme included for the source code.

============================================================================
---------------------------------- Credits ---------------------------------
============================================================================
jonwil
Sir_Kane
cfehunter
The Assembly Armada
Dghelneshi
CMDBob