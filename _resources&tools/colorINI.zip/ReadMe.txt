** colorINI :

colorINI is a plugin developped for Notepad ++ to help BFME INI coders in their navigation through code. 
It outlines the syntax based on certain keywords. 




** Installation Process :

Please install Notepad++ before installing the plugin




** Using colorINI :

follow the instructions here : http://ched.the3rdage.net/colorINI/


** Credits to : 

the whole Notepad ++ team for their wonderful program, Install creator team for their installer maker
Thanks to Hostile for T3A, and for everyone who makes it live by visiting the forums and helping each other out.
Special shout out to Phil (aka Gil Galad) for his jokes and keeping me busy :P




